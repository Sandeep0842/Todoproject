<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Todolist extends Model
{
     use HasFactory;
    /**
     * Write code on Method
     *
     * @return response()
     */
	 protected $table = 'tasks';
    protected $fillable = [
        'title', 'remark','status','updated_at','created_at'
    ];
}