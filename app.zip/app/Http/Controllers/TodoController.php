<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\Todolist;

class TodoController extends Controller
{
/**
     * Write code on Method
     *
     * @return response()
     */
    public function index()
    {
        $posts = Todolist::get();
  
        return view('posts', compact('posts'));
    }
  
    /**
     * Write code on Method
     *
     * @return response()
     */
    public function store(Request $request)
{
    // Validate incoming request
    $validator = Validator::make($request->all(), [
        'title' => 'required|string|max:255',
        'remark' => 'required|string',
    ]);

    // Check for validation failures
    if ($validator->fails()) {
        return response()->json([
            'error' => $validator->errors()->all()
        ]);
    }

    try {
        $todo = Todolist::create([
            'title' => $request->title,
            'remark' => $request->remark,
        ]);

        return response()->json([
            'success' => 'To do list created successfully.',
            'todo' => $todo  
        ]);
    } catch (\Exception $e) {
        return response()->json(['error' => 'Something went wrong. Please try again later.']);
    }
}

 public function update(Request $request, $id)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'remark' => 'nullable|string',
        ]);

        $post = Todolist::findOrFail($id);
        $post->title = $request->title;
        $post->remark = $request->remark;
        $post->save();
        return response()->json(['todo' => $post]);
    }
public function updateStatus(Request $request, $id)
{
    $request->validate([
        'status' => 'required|integer|in:0,1', 
    ]);

    $post = Todolist::findOrFail($id);
    $post->status = $request->status; 
    $post->save();

    return response()->json(['success' => true]);
}


public function delete($id)
{
    $todolist = Todolist::find($id);
    if ($todolist) {
        $todolist->delete();
        return response()->json([
            'success' => 'Task deleted successfully.',
            'todo' => $todolist  
        ]);
    } else {
        return response()->json([
            'error' => 'Item not found.'
        ]);
    }
}




}